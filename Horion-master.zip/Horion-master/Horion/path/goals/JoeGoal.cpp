#include "JoeGoal.h"
JoeGoal::~JoeGoal() {
}
