#pragma once

class CBlob {
public:
	void* data;
	size_t size;
};